let a1 = [];
let array =[];

for(let i=0;i<3;i++){
   
   for(let j=0; j<2;j++){
     array[j] =i++;
   }
  console.log(array);

}